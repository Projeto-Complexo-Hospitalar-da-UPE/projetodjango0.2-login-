const EnterButton = () => {
    return(
      <div>
        <button className="EnterButton"> Entrar </button>
      </div>
    );
}
export default EnterButton;